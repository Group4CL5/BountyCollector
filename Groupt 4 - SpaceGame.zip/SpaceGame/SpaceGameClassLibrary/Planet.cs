﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace SpaceGameClassLibrary
{
    class Planet
    {
        public Planet()
        {
            
        }
    }
}
