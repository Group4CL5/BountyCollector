﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceGameClassLibrary
{
    class RedSand:Planet
    {
        private int num1, num2;
        private char op = '+';

        
    }
}
